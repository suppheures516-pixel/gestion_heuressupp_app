from django.contrib import admin
from .models import UploadedExcel

admin.site.register(UploadedExcel)
